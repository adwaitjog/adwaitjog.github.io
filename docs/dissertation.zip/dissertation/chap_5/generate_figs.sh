#!/bin/sh

pdfcrop "figs/all_figures.pdf" "figs/all_figures-temp.pdf"
i=1
for fig_name in \
background \
ipc-model \
ipc-model-hardware \
motiv1-ws \
motiv1-it \
motiv2-ws \
motiv2-it \
example \
it-results \
ws-results \
overall-results-ws \
overall-results-it \
3app-ws \
3app-it \
how-its \
how-weis \
hws-results \
core-part-its 
do
	sh scripts/pdf_crop.sh $i figs/all_figures $fig_name;
	i=`expr $i + 1`
done
rm figs/all_figures-temp.pdf
#sh compile.sh
