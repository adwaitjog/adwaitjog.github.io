#!/bin/sh

pdfcrop "figs/all_figures.pdf" "figs/all_figures-temp.pdf"
i=1
for fig_name in \
lat_ipc_deviation \
pcc_source \
pcc_understand \
pcc_cons \
crr_cons \
pcc_ray \
crr_ray \
pcc_scp \
crr_scp \
pcc_luh \
crr_luh \
rank_dist \
rank_diff_dist \
static_ex \
static_ex_1 \
dyn_rt_ex \
dyn_rt_crt_ex \
scp_dyn_rt \
scp_dyn_rt_crt \
ipc \
stall \
rbl \
latency \
dyn_rt_cons \
dyn_crt_cons \
dyn_rt_scp \
dyn_crt_scp \
bw_dist \
pcc_reduce \
background \
rank_scale 

do
	sh scripts/pdf_crop.sh $i figs/all_figures $fig_name;
	i=`expr $i + 1`
done
rm figs/all_figures-temp.pdf
sh compile.sh
