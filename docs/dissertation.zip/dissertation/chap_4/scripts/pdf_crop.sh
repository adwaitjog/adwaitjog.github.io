#!/bin/sh

# Usage
# sh pdf_crop.sh <page number> <pdf file without ext> <output file name>

pdfcrop "$2.pdf" "$2-temp.pdf"
gs -sDEVICE=pdfwrite -dFirstPage=$1 -dLastPage=$1 -dNOPAUSE -dSAFER -dBATCH -dAutoRotatePages -sOutputFile="$3.pdf" "$2-temp.pdf"
mv "$3.pdf" ./figs/
rm  "$2-temp.pdf"

