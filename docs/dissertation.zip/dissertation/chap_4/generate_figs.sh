#!/bin/sh
# page_hit blp_dist

i=1
for fig_name in background wei_speed fairness_base bw_dist final_ws final_fairness final_it conceptual final_bw final_rbl
do
	sh scripts/pdf_crop.sh $i figs/all_figures $fig_name;
	i=`expr $i + 1`
done
sh compile.sh
