epstopdf $1.eps 
pdfcrop $1.pdf temp.pdf
mv temp.pdf $1.pdf 
