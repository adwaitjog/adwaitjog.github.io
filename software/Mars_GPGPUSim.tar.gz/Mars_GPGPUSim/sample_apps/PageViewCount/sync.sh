cp sync.sh MarsLib.cu MarsInc.h MarsUtils.cpp MarsScan.cu MarsSort.cu ../MatrixMul/
cp sync.sh MarsLib.cu MarsInc.h MarsUtils.cpp MarsScan.cu MarsSort.cu ../SimilarityScore/
cp sync.sh MarsLib.cu MarsInc.h MarsUtils.cpp MarsScan.cu MarsSort.cu ../StringMatch/
cp sync.sh MarsLib.cu MarsInc.h MarsUtils.cpp MarsScan.cu MarsSort.cu ../PageViewRank/
cp sync.sh MarsLib.cu MarsInc.h MarsUtils.cpp MarsScan.cu MarsSort.cu ../PageViewCount/
cp sync.sh MarsLib.cu MarsInc.h MarsUtils.cpp MarsScan.cu MarsSort.cu ../WordCount/
cp sync.sh MarsLib.cu MarsInc.h MarsUtils.cpp MarsScan.cu MarsSort.cu ../InvertedIndex/
cp sync.sh MarsLib.cu MarsInc.h MarsUtils.cpp MarsScan.cu MarsSort.cu ../Kmeans/
