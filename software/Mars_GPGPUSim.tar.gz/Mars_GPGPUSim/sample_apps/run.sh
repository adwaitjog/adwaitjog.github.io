#!/bin/sh
# Original Run Script Available with Mars is modified 
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#you must setup correct $SDK_PATH and $MARS_ROOT
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

SDK_PATH=$NVIDIA_CUDA_SDK_LOCATION
MARS_ROOT="$GPGPUSIM_ROOT/benchmarks/Mars_GPGPUSim"
SDK_SRC_PATH="$MARS_ROOT/sample_apps"

SS_BIN_DIR=$SDK_SRC_PATH/SimilarityScore
SM_BIN_DIR=$SDK_SRC_PATH/StringMatch
II_BIN_DIR=$SDK_SRC_PATH/InvertedIndex
PVC_BIN_DIR=$SDK_SRC_PATH/PageViewCount
PVR_BIN_DIR=$SDK_SRC_PATH/PageViewRank
MM_BIN_DIR=$SDK_SRC_PATH/MatrixMul
WC_BIN_DIR=$SDK_SRC_PATH/WordCount
KM_BIN_DIR=$SDK_SRC_PATH/Kmeans

USAGE="usage: run.sh [make|clean] all"
STR_MAKE="making source code..."

#check the number of command line arguments
if [ $# -lt 2 ]
then
	echo $USAGE
	exit
fi

#make source code
if [ "$1" = "make" ]
then
	echo $STR_MAKE
	case $2 in
		"all")
			echo $STR_MAKE_ALL
			cd $SS_BIN_DIR 
			make
			cd -
			cd $SM_BIN_DIR 
			make
			cd -
			cd $MM_BIN_DIR 
			make
			cd -
			cd $PVC_BIN_DIR 
			make
			cd -
			cd $PVR_BIN_DIR 
			make
			cd -
			cd $II_BIN_DIR 
			make
			cd -
			cd $WC_BIN_DIR
			make
			cd -
			cd $KM_BIN_DIR 
			make
			cd -
			echo "all done"
			;;
		*)
			echo $USAGE
			exit
			;;
	esac

#clean 
elif [ "$1" = "clean" ]
then
	echo "cleaning  files..."
	case $2 in
		"all")
			cd $SS_BIN_DIR 
			make clean
			cd -
			cd $SM_BIN_DIR 
			make clean
			cd -
			cd $MM_BIN_DIR 
			make clean
			cd -
			cd $PVC_BIN_DIR 
			make clean
			cd -
			cd $PVR_BIN_DIR 
			make clean
			cd -
			cd $II_BIN_DIR 
			make clean
			cd -
			cd $WC_BIN_DIR
			make clean
			cd -
			cd $KM_BIN_DIR 
			make clean
			cd -
			echo "all clean"
			;;
		*)
			echo $USAGE
			;;
	esac

#wrong arguments
else
	echo $USAGE
fi
